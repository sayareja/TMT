"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalStorage = void 0;
exports.LocalStorage = require("node-localstorage").LocalStorage;
