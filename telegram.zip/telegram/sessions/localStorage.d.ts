export declare const LocalStorage: any;
