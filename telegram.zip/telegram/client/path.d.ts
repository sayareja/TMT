import path from "path";
export default path;
