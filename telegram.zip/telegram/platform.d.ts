export declare const isDeno: boolean;
export declare const isBrowser: boolean;
export declare const isNode: boolean;
