import * as crypto from "crypto";
export default crypto;
