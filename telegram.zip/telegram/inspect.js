"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inspect = void 0;
var util_1 = require("util");
Object.defineProperty(exports, "inspect", { enumerable: true, get: function () { return util_1.inspect; } });
