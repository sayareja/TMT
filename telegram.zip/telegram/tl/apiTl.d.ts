declare const _exports: string;
export = _exports;
