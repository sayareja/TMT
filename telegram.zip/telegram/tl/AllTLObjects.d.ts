export declare const LAYER = 186;
declare const tlobjects: any;
export { tlobjects };
