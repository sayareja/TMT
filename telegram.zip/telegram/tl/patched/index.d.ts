declare function patchAll(): void;
export { patchAll };
