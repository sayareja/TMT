"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatGetter = void 0;
var chatGetter_1 = require("./chatGetter");
Object.defineProperty(exports, "ChatGetter", { enumerable: true, get: function () { return chatGetter_1.ChatGetter; } });
