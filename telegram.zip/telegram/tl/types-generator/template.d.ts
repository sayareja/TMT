declare function _exports({ types, constructors, functions }: {
    types: any;
    constructors: any;
    functions: any;
}): string;
export = _exports;
